package org.example;

import javax.swing.*;

public class Frame {
    public static JFrame nouveauFrame(String titreFrame){
        JFrame frame = new JFrame(titreFrame);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(550,450);
        frame.setLocationRelativeTo(null);
        return frame;
    }
}
