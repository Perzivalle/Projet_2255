package org.example;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
/**
 * Classe responsable de la gestion et de l'affichage des notifications
 * concernant les projets et leurs modifications.
 */
public class Notifications {

    private static JFrame frame;
    private JTable table;
    private static DefaultTableModel tableModel;
    private static List<String[]> modifications;
    /**
     * Constructeur de la classe Notifications.
     * Initialise la fenêtre et charge les notifications.
     */
    public Notifications() {
        frame = new JFrame("Notifications des Projets");
        frame.setSize(800, 600);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout());

        JLabel titleLabel = new JLabel("Notifications des Projets", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        panel.add(titleLabel, BorderLayout.NORTH);

        // Configuration de la JTable avec la nouvelle colonne
        String[] columnNames = {"Notifications (cliquez pour plus de détails)"};
        tableModel = new DefaultTableModel(columnNames, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Boutons d'action
        JPanel buttonPanel = new JPanel(new FlowLayout());
        JButton closeButton = new JButton("Fermer");
        closeButton.addActionListener(e -> frame.dispose());
        buttonPanel.add(closeButton);

        panel.add(buttonPanel, BorderLayout.SOUTH);

        frame.add(panel);
        frame.setVisible(true);

        // Charger les notifications
        loadNotifications("projetsSoumis.csv", "modificationsProjets.csv");

        // Ajouter un événement pour gérer le clic sur une ligne
        table.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting() && table.getSelectedRow() != -1) {
                afficherDetailsNotification(table.getSelectedRow());
            }
        });
    }

    /**
     * Charge les notifications à partir des fichiers donnés.
     *
     * @param fichierProjets      Le fichier contenant les projets soumis.
     * @param fichierModifications Le fichier contenant les modifications des projets.
     */
    public static void loadNotifications(String fichierProjets, String fichierModifications) {
        try {
            // Charger les projets soumis depuis la base de données
            List<String[]> projets = BaseDeDonnees.lireTous(fichierProjets);

            // Charger les modifications de projets depuis la base de données
            modifications = BaseDeDonnees.lireTous(fichierModifications);

            // Préparer les notifications pour affichage
            List<String[]> notifications = preparerNotifications(projets);

            tableModel.setRowCount(0); // Effacer les anciennes notifications
            for (String[] notification : notifications) {
                tableModel.addRow(new String[]{notification[0]});
            }

            // Ajouter les modifications comme notifications
            for (String[] modification : modifications) {
                tableModel.addRow(new String[]{"La modification d'un projet a été faite"});
            }

            if (notifications.isEmpty() && modifications.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Aucune notification disponible.", "Information", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, "Erreur lors du chargement des notifications.", "Erreur", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    /**
     * Compte le nombre total de notifications.
     *
     * @param fichierProjets      Le fichier contenant les projets soumis.
     * @param fichierModifications Le fichier contenant les modifications des projets.
     * @return Le nombre total de notifications.
     */
    public static int getNotificationCount(String fichierProjets, String fichierModifications) {
        try {
            // Compter les notifications dans projetsSoumis.csv
            List<String[]> projets = BaseDeDonnees.lireTous(fichierProjets);
            int countProjets = projets.size();

            // Compter les notifications dans modificationsProjets.csv
            List<String[]> modifications = BaseDeDonnees.lireTous(fichierModifications);
            int countModifications = modifications.size();

            // Additionner les deux
            return countProjets + countModifications;
        } catch (Exception e) {
            return 0; // En cas d'erreur, retourner 0
        }
    }


    /**
     * Prépare une liste de notifications à partir des projets soumis.
     *
     * @param projets La liste des projets soumis.
     * @return Une liste de notifications formatées.
     */

    public static List<String[]> preparerNotifications(List<String[]> projets) {
        List<String[]> notifications = new ArrayList<>();

        for (String[] projet : projets) {
            String typeNotif = "Un projet a été soumis"; // Par défaut, supposons que chaque ligne est un projet soumis
            notifications.add(new String[]{typeNotif, projet[0], projet[1], projet[2], projet[3], projet[4], projet[5], projet[6]});
        }

        return notifications;
    }
    /**
     * Affiche les détails d'une notification sélectionnée.
     *
     * @param selectedRow L'index de la ligne sélectionnée.
     */
    private void afficherDetailsNotification(int selectedRow) {
        try {
            int projetsCount = BaseDeDonnees.lireTous("projetsSoumis.csv").size();

            if (selectedRow < projetsCount) {
                // Notification provenant de projetsSoumis.csv
                List<String[]> projets = BaseDeDonnees.lireTous("projetsSoumis.csv");
                String[] projet = projets.get(selectedRow);

                // Afficher les détails dans une nouvelle fenêtre
                String details = String.format(
                        "Titre : %s%nType : %s%nQuartiers : %s%nRues : %s%nDate Début : %s%nDate Fin : %s%nStatut : %s",
                        projet[0], projet[1], projet[2], projet[3], projet[4], projet[5], projet[6]
                );

                JOptionPane.showMessageDialog(frame, details, "Détails de la Notification", JOptionPane.INFORMATION_MESSAGE);
            } else {
                // Notification provenant de modificationsProjets.csv
                int modificationIndex = selectedRow - projetsCount;
                String[] modification = modifications.get(modificationIndex);

                // Afficher les détails de la modification
                String details = String.format(
                        "Titre du projet : %s%nType de modification : %s%nAncienne valeur : %s%nNouvelle valeur : %s",
                        modification[0], modification[1], modification[2], modification[3]
                );

                JOptionPane.showMessageDialog(frame, details, "Détails de la Modification", JOptionPane.INFORMATION_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(frame, "Erreur lors de l'affichage des détails.", "Erreur", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
    /**
     * Point d'entrée principal pour lancer l'application Notifications.
     *
     * @param args Arguments de la ligne de commande.
     */
    public static void main(String[] args) {
        SwingUtilities.invokeLater(Notifications::new);
    }
}