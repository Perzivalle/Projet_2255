package org.example;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Cette classe fournit des méthodes statiques pour la manipulation de fichiers qui agissent comme une simple base de données textuelle.
 */

public class BaseDeDonnees {

    /**
     * Lit toutes les lignes d'un fichier donné et les retourne sous forme de liste de tableaux de String.
     *
     * @param fichier Le chemin du fichier à lire.
     * @return Une liste de tableaux de String, chaque tableau représentant une ligne du fichier.
     */

    public static List<String[]> lireTous(String fichier) {
        List<String[]> enregistrements = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(fichier))) {
            String ligne;
            while ((ligne = reader.readLine()) != null) {
                String[] valeurs = ligne.split(",", -1); // Utiliser -1 pour inclure les champs vides
                enregistrements.add(valeurs);
            }
        } catch (FileNotFoundException e) {
            System.err.println("Fichier introuvable : " + fichier);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return enregistrements;
    }

    /**
     * Écrit une liste d'enregistrements dans un fichier.
     *
     * @param filePath Le chemin du fichier où écrire.
     * @param data Les données à écrire, où chaque tableau de String représente une ligne du fichier.
     */

    public static void ecrireTous(String filePath, List<String[]> data) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (String[] row : data) {
                writer.write(String.join(",", row));
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Erreur lors de l'écriture dans le fichier : " + filePath);
            e.printStackTrace();
        }
    }

    /**
     * Écrit un tableau de String à la fin d'un fichier, chaque String étant une colonne.
     *
     * @param fichier Le chemin du fichier où écrire.
     * @param valeurs Les valeurs à écrire dans le fichier.
     */

    public static void ecrire(String fichier, String[] valeurs) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fichier, true))) {
            writer.write(String.join(",", valeurs));
            writer.newLine();
        } catch (IOException e) {
            System.err.println("Erreur lors de l'écriture dans le fichier : " + fichier);
            e.printStackTrace();
        }
    }

    /**
     * Ajoute une ligne à un fichier existant.
     *
     * @param nomFichier Le fichier où ajouter la ligne.
     * @param ligne La ligne à ajouter, où chaque élément de la liste est une colonne dans la ligne du fichier.
     */

    public static void ajouterLigne(String nomFichier, List<String> ligne) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(nomFichier, true))) {
            writer.write(String.join(",", ligne));
            writer.newLine();
        } catch (IOException e) {
            throw new RuntimeException("Erreur lors de l'ajout d'une ligne au fichier : " + nomFichier, e);
        }
    }
    /**
     * Réécrit un fichier complet avec une nouvelle liste d'enregistrements.
     *
     * @param fichier Le chemin du fichier à réécrire.
     * @param enregistrements Les nouveaux enregistrements à écrire dans le fichier.
     */

    public static void reecrire(String fichier, List<String[]> enregistrements) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fichier))) {
            for (String[] valeurs : enregistrements) {
                writer.write(String.join(",", valeurs));
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Erreur lors de la réécriture du fichier : " + fichier);
            e.printStackTrace();
        }
    }

    /**
     * Supprime des lignes d'un fichier en fonction d'une condition spécifiée.
     *
     * @param fichier Le fichier dont les lignes doivent être supprimées.
     * @param condition La condition à tester pour chaque ligne pour déterminer si elle doit être supprimée.
     */

    public static void supprimer(String fichier, ConditionSuppression condition) {
        List<String[]> enregistrements = lireTous(fichier);
        List<String[]> enregistrementsMisAJour = new ArrayList<>();

        for (String[] enregistrement : enregistrements) {
            if (!condition.tester(enregistrement)) {
                enregistrementsMisAJour.add(enregistrement);
            }
        }

        reecrire(fichier, enregistrementsMisAJour);
    }

    /**
     * Interface fonctionnelle pour définir des conditions de suppression d'enregistrements dans un fichier.
     */

    @FunctionalInterface
    public interface ConditionSuppression {
        boolean tester(String[] enregistrement);
    }
}