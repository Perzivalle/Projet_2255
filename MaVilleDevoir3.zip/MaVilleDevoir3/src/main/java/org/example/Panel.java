package org.example;

import javax.swing.*;
import java.awt.*;

public class Panel {

    public static JPanel panelTitrePage(String titrePage){
        JPanel panelEnTete = new JPanel(new BorderLayout());

        JLabel titre = new JLabel(titrePage, SwingConstants.CENTER);
        titre.setFont(titre.getFont().deriveFont(30f));
        panelEnTete.add(titre, BorderLayout.CENTER);



        return panelEnTete;
    }
}