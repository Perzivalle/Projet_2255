package org.example;

import org.example.code.App;
import com.google.gson.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZonedDateTime;
import java.time.format.DateTimeParseException;
/**
 * Cette classe est responsable de l'affichage des demandes de travaux à partir d'une réponse d'API.
 * Elle permet aux utilisateurs de visualiser, filtrer et interagir avec les demandes de travaux en utilisant une interface graphique.
 */
public class ConsulterTravaux {
    /**
     * Méthode pour initialiser et afficher les demandes de travaux si l'appel API est réussi.
     */
    public static void ConsulterTravaux() {
        if (App.responseTravaux == null || App.responseTravaux.getStatusCode() != 200) {
            JOptionPane.showMessageDialog(null, "Erreur de données de travaux","Erreur", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String jsonResponseTravaux = App.responseTravaux.getBody();  // on va chercher les donnees dans le body et le mettre en json pour faciliter le processus
        Gson gson = new Gson();
        JsonObject jsonObject = gson.fromJson(jsonResponseTravaux, JsonObject.class);
        JsonArray records = jsonObject.getAsJsonObject("result").getAsJsonArray("records");

        String[] nomColonnes = {"ID","BoroughId","CurrentStatus","ReasonCategory","SubmitterCategory","OrganizationName"};
        Object[][] donnees = new Object[records.size()][6];

        int range = 0;
        for (JsonElement record : records){
            JsonObject obj = record.getAsJsonObject();
            donnees[range][0] = obj.has("id") && !obj.get("id").isJsonNull() ? obj.get("id").getAsString() : "Indisponible";
            donnees[range][1] = obj.has("boroughid") && !obj.get("boroughid").isJsonNull() ? obj.get("boroughid").getAsString() : "Indisponible";
            donnees[range][2] = obj.has("currentstatus") && !obj.get("currentstatus").isJsonNull() ? obj.get("currentstatus").getAsString() : "Indisponible";
            donnees[range][3] = obj.has("reason_category") && !obj.get("reason_category").isJsonNull() ? obj.get("reason_category").getAsString() : "Indisponible";
            donnees[range][4] = obj.has("submittercategory") && !obj.get("submittercategory").isJsonNull() ? obj.get("submittercategory").getAsString() : "Indisponible";
            donnees[range][5] = obj.has("organizationname") && !obj.get("organizationname").isJsonNull() ? obj.get("organizationname").getAsString() : "Indisponible";
            range++;
        }

        JFrame frameConsulterTravaux = Frame.nouveauFrame("MaVille");
        frameConsulterTravaux.setVisible(true);

        JPanel panelConsulterTravaux = new JPanel(new BorderLayout());
        JPanel panelEnTete = Panel.panelTitrePage("Consultation des travaux");
        panelConsulterTravaux.add(panelEnTete, BorderLayout.NORTH);
        JPanel bouton = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton retour = new JButton("Retour");
        bouton.add(retour);
        panelEnTete.add(retour, BorderLayout.WEST);
        retour.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                frameConsulterTravaux.dispose();
                Main.createPageMenuOptionsResident();
            }
        });

        //On va creer un JTable pour illustrer aux users les travaux
        JTable tableTravaux = new JTable(donnees,nomColonnes);
        tableTravaux.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);

        //On va creer un JScrollPane pour que le user puisse defiler et bien voir les informations
        JScrollPane scrollPaneTravaux = new JScrollPane(tableTravaux);
        scrollPaneTravaux.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        panelConsulterTravaux.add(scrollPaneTravaux,BorderLayout.CENTER);

        //On va creer l'implémentation qui permet de filtrer les entraves à afficher
        JPanel panelFiltreTravaux = new JPanel(new FlowLayout());
        JTextField inputFiltre = new JTextField(15);
        JButton filtrer = new JButton("Filtrer");
        JButton prochainsMois = new JButton("Voir 3 prochains mois");
        JButton reinitialiser = new JButton("Réinitialiser");
        String[] typesFiltre = {"boroughid", "ID"};
        JComboBox<String> comboBoxTypeFiltre = new JComboBox<>(typesFiltre);

        panelFiltreTravaux.add(inputFiltre);
        panelFiltreTravaux.add(comboBoxTypeFiltre);
        panelFiltreTravaux.add(filtrer);
        panelFiltreTravaux.add(prochainsMois);
        panelFiltreTravaux.add(reinitialiser);

        panelConsulterTravaux.add(panelFiltreTravaux, BorderLayout.SOUTH);

        frameConsulterTravaux.add(panelConsulterTravaux);
        frameConsulterTravaux.setVisible(true);

        filtrer.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String choixFiltre = (String) comboBoxTypeFiltre.getSelectedItem();
                String inputDonneeFiltre = inputFiltre.getText().trim().toLowerCase();

                Object[][] donneesFiltrer = new Object[records.size()][6];
                int i = 0;
                if ("boroughid".equals(choixFiltre)){
                    for (JsonElement record : records){
                        JsonObject obj = record.getAsJsonObject();
                        String boroughId = obj.has("boroughid") && !obj.get("boroughid").isJsonNull() ? obj.get("boroughid").getAsString().trim().toLowerCase() : "Indisponible";
                        if (boroughId.equals(inputDonneeFiltre)){
                            donneesFiltrer[i][0] = obj.has("id") && !obj.get("id").isJsonNull() ? obj.get("id").getAsString() : "Indisponible";
                            donneesFiltrer[i][1] = boroughId;
                            donneesFiltrer[i][2] = obj.has("currentstatus") && !obj.get("currentstatus").isJsonNull() ? obj.get("currentstatus").getAsString() : "Indisponible";
                            donneesFiltrer[i][3] = obj.has("reason_category") && !obj.get("reason_category").isJsonNull() ? obj.get("reason_category").getAsString() : "Indisponible";
                            donneesFiltrer[i][4] = obj.has("submittercategory") && !obj.get("submittercategory").isJsonNull() ? obj.get("submittercategory").getAsString() : "Indisponible";
                            donneesFiltrer[i][5] = obj.has("organizationname") && !obj.get("organizationname").isJsonNull() ? obj.get("organizationname").getAsString() : "Indisponible";
                            i++;
                        }
                    }
                } else if ("ID".equals(choixFiltre)) {
                    for (JsonElement record : records){
                        JsonObject obj = record.getAsJsonObject();
                        String id = obj.has("id") && !obj.get("id").isJsonNull() ? obj.get("id").getAsString().trim().toLowerCase() : "Indisponible";
                        if (id.equals(inputDonneeFiltre)){
                            donneesFiltrer[i][0] = id;
                            donneesFiltrer[i][1] = obj.has("boroughid") && !obj.get("boroughid").isJsonNull() ? obj.get("boroughid").getAsString() : "Indisponible";
                            donneesFiltrer[i][2] = obj.has("currentstatus") && !obj.get("currentstatus").isJsonNull() ? obj.get("currentstatus").getAsString() : "Indisponible";
                            donneesFiltrer[i][3] = obj.has("reason_category") && !obj.get("reason_category").isJsonNull() ? obj.get("reason_category").getAsString() : "Indisponible";
                            donneesFiltrer[i][4] = obj.has("submittercategory") && !obj.get("submittercategory").isJsonNull() ? obj.get("submittercategory").getAsString() : "Indisponible";
                            donneesFiltrer[i][5] = obj.has("organizationname") && !obj.get("organizationname").isJsonNull() ? obj.get("organizationname").getAsString() : "Indisponible";
                            i++;
                        }
                    }
                }
                DefaultTableModel nouvelleTableTravaux = new DefaultTableModel(donneesFiltrer,nomColonnes);
                tableTravaux.setModel(nouvelleTableTravaux);
            }
        });

        prochainsMois.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Object[][] donneesProchainsMoisFiltrer = new Object[records.size()][6];
                int i = 0;

                LocalDateTime aujourdhui = LocalDateTime.now();
                LocalDateTime prochainsMois = aujourdhui.plusMonths(3);

                for (JsonElement record : records){
                    JsonObject obj = record.getAsJsonObject();
                    if (obj.has("duration_start_date")&& !obj.get("duration_start_date").isJsonNull()){
                        String dateDebut = obj.get("duration_start_date").getAsString();
                        try {
                            // Permet de convertir et extraire les informations pour juste avoir la date et l'heure
                            ZonedDateTime debutDateHoraire = ZonedDateTime.parse(dateDebut);
                            LocalDateTime debutDate = debutDateHoraire.toLocalDateTime();

                            if (!debutDate.isBefore(aujourdhui) && !debutDate.isAfter(prochainsMois)){
                                donneesProchainsMoisFiltrer[i][0] = obj.has("id") && !obj.get("id").isJsonNull() ? obj.get("id").getAsString() : "Indisponible";
                                donneesProchainsMoisFiltrer[i][1] = obj.has("boroughid") && !obj.get("boroughid").isJsonNull() ? obj.get("boroughid").getAsString() : "Indisponible";
                                donneesProchainsMoisFiltrer[i][2] = obj.has("currentstatus") && !obj.get("currentstatus").isJsonNull() ? obj.get("currentstatus").getAsString() : "Indisponible";
                                donneesProchainsMoisFiltrer[i][3] = obj.has("reason_category") && !obj.get("reason_category").isJsonNull() ? obj.get("reason_category").getAsString() : "Indisponible";
                                donneesProchainsMoisFiltrer[i][4] = obj.has("submittercategory") && !obj.get("submittercategory").isJsonNull() ? obj.get("submittercategory").getAsString() : "Indisponible";
                                donneesProchainsMoisFiltrer[i][5] = obj.has("organizationname") && !obj.get("organizationname").isJsonNull() ? obj.get("organizationname").getAsString() : "Indisponible";
                                i++;
                            }
                        } catch (DateTimeParseException exception) {
                            System.err.println("Invalide:" + dateDebut);
                        }
                    }
                }
                DefaultTableModel nouvelleTableTravaux = new DefaultTableModel(donneesProchainsMoisFiltrer,nomColonnes);
                tableTravaux.setModel(nouvelleTableTravaux);
            }
        });


        reinitialiser.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                DefaultTableModel reinitialiserTableTravaux = new DefaultTableModel(donnees, nomColonnes);
                tableTravaux.setModel(reinitialiserTableTravaux);
                //Permet de s'assurer que le champs soit libre pour taper à nouveau
                inputFiltre.setText("");
            }
        });
    }
}