package org.example;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

/**
 * La classe PlanificationParticipative gère l'interface utilisateur pour la planification participative de travaux.
 * Elle permet aux utilisateurs de soumettre de nouveaux travaux et des préférences horaires pour des travaux existants.
 */

public class PlanificationParticipative {

    private static final String TRAVAUX_FILE = "propositionsTravaux.csv";
    private static final String PREFERENCES_FILE = "preferencesHoraires.csv";
    private JFrame frame;
    private JTable travauxTable;
    private JTable preferencesTable;
    private DefaultTableModel travauxTableModel;
    private DefaultTableModel preferencesTableModel;
    /**
     * Constructeur qui initialise les composants de l'interface utilisateur et charge les données.
     */
    public PlanificationParticipative() {
        frame = new JFrame("Planification Participative");
        frame.setSize(1000, 600);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setLayout(new BorderLayout());

        JLabel titleLabel = new JLabel("Planification Participative", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        frame.add(titleLabel, BorderLayout.NORTH);

        // Table pour consulter les travaux proposés
        String[] travauxColumns = {"Titre", "Description", "Quartier", "Date Début", "Date Fin", "Proposé par"};
        travauxTableModel = new DefaultTableModel(travauxColumns, 0);
        travauxTable = new JTable(travauxTableModel);
        JScrollPane travauxScrollPane = new JScrollPane(travauxTable);

        // Table pour consulter les préférences horaires
        String[] preferencesColumns = {"Quartier", "Titre du Travail", "Horaires Proposés", "Nom du Résident"};
        preferencesTableModel = new DefaultTableModel(preferencesColumns, 0);
        preferencesTable = new JTable(preferencesTableModel);
        JScrollPane preferencesScrollPane = new JScrollPane(preferencesTable);

        // Panneau pour soumettre des travaux
        JPanel travauxPanel = new JPanel(new GridLayout(7, 2, 10, 10));
        JLabel titreLabel = new JLabel("Titre du Travail :");
        JTextField titreField = new JTextField();
        JLabel descriptionLabel = new JLabel("Description :");
        JTextArea descriptionField = new JTextArea(3, 20);
        JLabel quartierLabel = new JLabel("Quartier :");
        JTextField quartierField = new JTextField();
        JLabel dateDebutLabel = new JLabel("Date Début (JJ/MM/AAAA) :");
        JTextField dateDebutField = new JTextField();
        JLabel dateFinLabel = new JLabel("Date Fin (JJ/MM/AAAA) :");
        JTextField dateFinField = new JTextField();
        JLabel nomLabel = new JLabel("Votre Nom :");
        JTextField nomField = new JTextField();

        JButton soumettreTravailButton = new JButton("Soumettre Travail");
        travauxPanel.add(titreLabel);
        travauxPanel.add(titreField);
        travauxPanel.add(descriptionLabel);
        travauxPanel.add(new JScrollPane(descriptionField));
        travauxPanel.add(quartierLabel);
        travauxPanel.add(quartierField);
        travauxPanel.add(dateDebutLabel);
        travauxPanel.add(dateDebutField);
        travauxPanel.add(dateFinLabel);
        travauxPanel.add(dateFinField);
        travauxPanel.add(nomLabel);
        travauxPanel.add(nomField);
        travauxPanel.add(soumettreTravailButton);

        // Boutons pour soumettre des préférences et retourner au menu
        JButton soumettrePreferenceButton = new JButton("Proposer une Plage Horaire");
        JButton retourButton = new JButton("Retour");

        // Ajouter les composants au panneau principal
        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, travauxScrollPane, preferencesScrollPane);
        splitPane.setDividerLocation(500);
        frame.add(splitPane, BorderLayout.CENTER);
        frame.add(travauxPanel, BorderLayout.SOUTH);

        JPanel buttonPanel = new JPanel(new FlowLayout());
        buttonPanel.add(soumettrePreferenceButton);
        buttonPanel.add(retourButton);
        frame.add(buttonPanel, BorderLayout.EAST);

        // Charger les travaux et préférences dès l'ouverture
        chargerTravaux();
        chargerPreferences();

        // Action : Soumettre un travail
        soumettreTravailButton.addActionListener(e -> {
            String titre = titreField.getText().trim();
            String description = descriptionField.getText().trim();
            String quartier = quartierField.getText().trim();
            String dateDebut = dateDebutField.getText().trim();
            String dateFin = dateFinField.getText().trim();
            String nom = nomField.getText().trim();

            if (titre.isEmpty() || description.isEmpty() || quartier.isEmpty() || dateDebut.isEmpty() || dateFin.isEmpty() || nom.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Tous les champs doivent être remplis.", "Erreur", JOptionPane.ERROR_MESSAGE);
                return;
            }

            ajouterTravail(titre, description, quartier, dateDebut, dateFin, nom);
            JOptionPane.showMessageDialog(frame, "Travail soumis avec succès !", "Succès", JOptionPane.INFORMATION_MESSAGE);
            chargerTravaux();
        });

        // Action : Proposer une plage horaire
        soumettrePreferenceButton.addActionListener(e -> {
            int selectedRow = travauxTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(frame, "Veuillez sélectionner un travail pour proposer une plage horaire.", "Erreur", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String titreTravail = travauxTableModel.getValueAt(selectedRow, 0).toString();
            String quartierTravail = travauxTableModel.getValueAt(selectedRow, 2).toString();
            String horaire = JOptionPane.showInputDialog(frame, "Entrez vos plages horaires (ex : 08:00-12:00) :");
            String nom = JOptionPane.showInputDialog(frame, "Entrez votre nom :");

            if (horaire == null || horaire.isEmpty() || nom == null || nom.isEmpty()) {
                JOptionPane.showMessageDialog(frame, "Les horaires et le nom doivent être renseignés.", "Erreur", JOptionPane.ERROR_MESSAGE);
                return;
            }

            ajouterPreference(quartierTravail, titreTravail, horaire, nom);
            JOptionPane.showMessageDialog(frame, "Préférence ajoutée avec succès !", "Succès", JOptionPane.INFORMATION_MESSAGE);
            chargerPreferences();
        });

        // Action : Retour
        retourButton.addActionListener(e -> frame.dispose());

        frame.setVisible(true);
    }

    private void ajouterTravail(String titre, String description, String quartier, String dateDebut, String dateFin, String nom) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(TRAVAUX_FILE, true))) {
            writer.write(String.join(",", titre, description, quartier, dateDebut, dateFin, nom));
            writer.newLine();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "Erreur lors de l'enregistrement du travail.", "Erreur", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void ajouterPreference(String quartier, String titreTravail, String horaire, String nom) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(PREFERENCES_FILE, true))) {
            writer.write(String.join(",", quartier, titreTravail, horaire, nom));
            writer.newLine();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "Erreur lors de l'enregistrement de la préférence.", "Erreur", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void chargerTravaux() {
        List<String[]> travaux = lireFichier(TRAVAUX_FILE);
        travauxTableModel.setRowCount(0);
        for (String[] travail : travaux) {
            travauxTableModel.addRow(travail);
        }
    }

    private void chargerPreferences() {
        List<String[]> preferences = lireFichier(PREFERENCES_FILE);
        preferencesTableModel.setRowCount(0);
        for (String[] preference : preferences) {
            preferencesTableModel.addRow(preference);
        }
    }

    private List<String[]> lireFichier(String fichier) {
        List<String[]> data = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(fichier))) {
            String ligne;
            while ((ligne = reader.readLine()) != null) {
                data.add(ligne.split(",", -1));
            }
        } catch (IOException e) {
            System.out.println("Erreur lors de la lecture du fichier : " + fichier);
        }
        return data;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(PlanificationParticipative::new);
    }
}